/**********************************************
BPGETTCH.C - Poll bus controller for touch data
***********************************************/

#include <stdio.h>
#include <conio.h>

typedef int boolean;
typedef unsigned char byte;

#define FALSE 0
#define TRUE !FALSE

#define BASEPORT 0x280           /* as jumpered on card */

struct bufferentry {             /* touch data structure */
   byte data[6];                 /* serial data */
} point;

boolean gettouch(int *x, int *y);/* returns coordinate data */
boolean packet(void);            /* polls controller for data */

void _cdecl main(void)
{
   int x, y;

   printf("Touch screen for polled coordinate output.\n");
   printf("Press any key to abort...\n");
   do /* poll controller for touch and display if data available */
      if (gettouch(&x, &y))
         printf("X=%4d Y=%4d\n", x, y);
   while (!kbhit()); getch();
}

boolean gettouch(int *x, int *y)
{
/* Poll controller for data. Return valid data if found. */
   byte s;

   if (!packet())
      return(FALSE);             /* no data */
   s = (byte)inp(BASEPORT+2);    /* get controller status */
   if (s & 0x01) {               /* 8 bit mode */
      *x = point.data[0] << 4;
      *y = point.data[1] << 4;
      return(TRUE);
   }
   else {                        /* 12 bit mode */
      *x = (point.data[0] << 4) | (point.data[1] >> 4);
      *y = (point.data[2] << 4) | (point.data[3] >> 4);
      return(TRUE);
   }
}

boolean packet(void)
{
/* poll controller for data */
   byte s;
   boolean dataaquired = FALSE;

   do {
      s = (byte)inp(BASEPORT+2); /* get controller status */
      if (s < 0x80) {            /* data not ready */
         if (s & 0x20)           /* resync necessary (if E271-141 controller) */
            s = (byte)inp(BASEPORT+1); /* resync controller */
         return(FALSE);
      }
      else if (s & 0x01) {       /* 8 bit mode */
         point.data[0] = (byte)inp(BASEPORT);   /* get X... */
         point.data[1] = (byte)inp(BASEPORT+1); /* and Y */
         dataaquired = TRUE;
         do ; while (inp(BASEPORT+2) >= 0x80);           /* wait for not ready */
      }
      else if (s & 0x40) {       /* 12 bit mode - Get X */
         point.data[0] = (byte)inp(BASEPORT);   /* X high */
         point.data[1] = (byte)inp(BASEPORT+1); /* X low */
         do ; while ((inp(BASEPORT+2) & 0x40) == 0x40);  /* wait for X bit to clear */
      }                          /* re-poll before reading Y */
      else {                     /* get Y */
         point.data[2] = (byte)inp(BASEPORT);   /* Y high */
         point.data[3] = (byte)inp(BASEPORT+1); /* Y low */
         dataaquired = TRUE;
         do ; while ((inp(BASEPORT+2) & 0xc0) == 0x80);  /* wait for not ready or X bit */
      }
   } while (!dataaquired);
   return(TRUE);
}
