/*************************************************************************

EXAMPLE2.C
   Polls Elo SmartSet touchscreen controllers.
   Acquires calibration points through extrapolation.
   Sets calibration, scaling, and mode in controller.
   Finishes with 80x25 finger painting.

**************************************************************************/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "packet.c"              /* SmartSet interface-independent code */
#include "pc_misc.c"             /* miscellaneous PC-dependent code */

void getcalibration(int *xlow, int *xhigh,
                    int *ylow, int *yhigh, boolean *xyswap);
void getpoint(int x, int y, int *tx, int *ty);
void outstr(int x, int y, char *s);
void xch(int *i1, int *i2);

/*************************************************************************/

int _cdecl main(void)
{
   int x,y,z,flags,xlow,xhigh,ylow,yhigh;
   packettype packet;
   unsigned *p;
   boolean xyswapflag;

   initcontroller();
   checkdiags();

   /* calibrate touchscreen */
   /* To acquire calibration points, controller must be in raw coordinate
      mode. We use the point of untouch as our calibration point. */
   packet[0] = 'm'; querycommand(packet); /* get current mode */
   packet[2] = 0x84;                      /* untouch and no Z modes */
   packet[3] = 0x00;                      /* raw coordinates only */
   setcommand(packet);                    /* set modes for calibration */
   packet[0] = 'c'; packet[1] = 'S';      /* get swap axes flag */
   querycommand(packet);
   packet[2] = 0; setcommand(packet);     /* insure axes are not swapped */
   getcalibration(&xlow,&xhigh,&ylow,&yhigh,&xyswapflag);   /* corners of image */
   packet[0] = 'C'; packet[1] = 'X';
   p = (unsigned *)packet; *++p = xlow; *++p = xhigh;
   setcommand(packet);                    /* set X calibration points */
   packet[1] = 'Y';
   p = (unsigned *)packet; *++p = ylow; *++p = yhigh;
   setcommand(packet);                    /* set Y calibration points */
   packet[0] = 'c'; packet[1] = 'S'; querycommand(packet);
   packet[2] = (byte)xyswapflag;
   setcommand(packet);                    /* set swap axes flag as necessary */

   /* set scaling to 1..80, 1..25 */
   packet[0] = 'S'; packet[1] = 'X';
   p = (unsigned *)packet; *++p = 1; *++p = 80; *++p = 0; setcommand(packet);
   packet[1] = 'Y';
   p = (unsigned *)packet; *++p = 1; *++p = 25; setcommand(packet);
   packet[0] = 's'; packet[1] = 'S'; querycommand(packet);
   packet[2] &= ~0x07; setcommand(packet);/* axis inversion bits not used */

   /* set mode */
   packet[0] = 'm'; querycommand(packet); /* get current mode */
   packet[2] |= 0x47;   /* Range Checking, Initial, Stream, Untouch Modes */
   packet[3] |= 0x0e;   /* Calibration, Scaling, and Trim Modes */
   setcommand(packet);                    /* set modes for normal operation */

   /* Calibration, Scaling, and Mode may be stored in on-board NVRAM here
   with the NVRAM command. Remove jumper J7 to boot controller from NVRAM. */
   
   /* finger painting */
   printf("\nPress a key to proceed to finger painting...");
   getch();
   clearscreen(); cursoroff();
   do {
      if (gettouch(&x,&y,&z,&flags))
         outstr(x,y,"*");
   } while (!kbhit()); getch();
   closescreen();
   return(0);
}

void getcalibration(int *xlow, int *xhigh,
                    int *ylow, int *yhigh, boolean *xyswap)
/* Returns raw coordinates at upper left and lower right corners of the screen
   image. These points are determined by extrapolation from calibration points
   taken in slightly from the corners. This reduces the effects of "pin cushion"
   on calibration. The third calibration point is used to detect swapped axes -
   touchscreen is rotated 90 degrees or cable is connected
   backwards on DuraTouch touchscreens (no longer manufactured by Elo). */
{
   int      rightx, leftx,                   /* position of touch targets */
            uppery, lowery,
            xmin=1,ymin=1,xmax=80,ymax=25,   /* screen coordinate system */
            x1, y1, x2, y2, sx, sy,          /* raw touch coordinates */
            loop;
   double   xunit, yunit;                    /* # of touch points per screen coord */
   boolean  xinv,yinv;

   openscreen(); clearscreen(); cursoroff();
   
   for (loop = 2; loop <= 79; loop++) {      /* draw box indicating video image extremes */
      outstr(loop, 1, "X"); outstr(loop, 25, "X");
   }
   for (loop = 1; loop <= 24; loop++) {
      outstr(1, loop, "X"); outstr(80, loop, "X");
   }
   screenbase[3840] = screenbase[3998] = (byte)'X';   /* don't scroll */
   outstr(22, 12, "Touch the following points from a");
   outstr(22, 13, "position of normal use, e.g. a sitting");
   outstr(22, 14, "person of average height and reach.");
   outstr(22, 15, "You will hear a beep after each touch.");

   /* To improve sample, we use points close to the edge of the screen image.
   We then extrapolate to the actual edge of the image. */
   leftx  =  xmax / 8;        uppery =  ymax / 8 + 1;
   rightx = (xmax / 8) * 7;   lowery = (ymax / 8) * 7;

   getpoint( leftx, uppery, &x1, &y1);    /* origin */
   getpoint(rightx, lowery, &x2, &y2);    /* diagonally opposite corner */
   getpoint(rightx, uppery, &sx, &sy);    /* for detecting swapped axes */

   /* compute number of touch points per screen coordinate */
   xunit = (double)(x2 - x1) / (rightx - leftx);
   yunit = (double)(y2 - y1) / (lowery - uppery);
   /* extrapolate the calibration points to corner points of screen image */
   *xhigh = x2 + (int)(xunit * (xmax - rightx));
   *xlow  = x1 - (int)(xunit * (leftx - xmin));
   if (*xlow  < 1) *xlow  = 1;
   if (*xhigh < 1) *xhigh = 1;         /* in case axis inverted */
   *yhigh = y2 + (int)(yunit * (ymax - lowery));
   *ylow  = y1 - (int)(yunit * (uppery - ymin));
   if (*ylow  < 1) *ylow  = 1;
   if (*yhigh < 1) *yhigh = 1;
   /* these variables now contain the raw coordinates the controller would
      output for the extremes of the video image */

   /* detect touchscreen orientation corrections */
   *xyswap = abs(sx - x1) < abs(sy - y1);
   if (*xyswap) {
      xch(xhigh, yhigh);
      xch(xlow, ylow);
   }
   xinv = *xhigh < *xlow;
   yinv = *yhigh < *ylow;

   /* display results of calibration - useful for troubleshooting */
   clearscreen(); cursoron();
   printf("Calibration points are: %d,%d,  %d,%d\n",*xlow,*ylow,*xhigh,*yhigh);
   if (xinv)
      printf("X axis inverted.\n");
   if (yinv)
      printf("Y axis inverted.\n");    /* normal */
   if (*xyswap)
      printf("X and Y axes swapped.\n");
   if (xinv || yinv || *xyswap)
      printf("Orientation adjusted.\n");
   /* Axis inversion is automatically accomplished by the signed arithmetic
      in the controller. The controller must be told to swap axes however. */
}

void getpoint(int x, int y, int *tx, int *ty)
/* display target at x,y, return touch coordinate */
{
   int z,flags;

   outstr(x, y, "*");            /* display target */
   while (!gettouch(tx, ty, &z, &flags)) ;
   outstr(x, y, " \a");          /* remove target, beep */
}

void outstr(int x, int y, char *s)
/* display string at x,y */
{
   cursorxy(x, y);
   printf("%s",s);
}

void xch(int *i1, int *i2)
/* swap integers */
{
   int t;

   t = *i1; *i1 = *i2; *i2 = t;
}

#include "bus.c"              /* for E271-2201 and E271-2202 */
/* #include "serial.c" */     /* for E271-2200 and E271-2210 */
