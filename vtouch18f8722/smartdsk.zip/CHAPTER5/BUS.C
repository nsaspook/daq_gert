/************ E271-2201, E271-2202 controller-dependent code *************/

#define DEFAULTBASEPORT 0x280    /* default base port address of E271-2201 */
#define IBM_ID 0x6253            /* IBM assigned Micro Channel adapter ID for E271-2202 */

unsigned baseport;               /* controller base I/O port */
boolean mca;                     /* true if Micro Channel */

int initbuscontroller(void);
int clearbuscontroller(void);
boolean getanypacketbus(packettype packet);
boolean checkmca(void);
int findmcacontroller(void);
void resetmcacontrollerpos(void);

void initcontroller(void)
{
   int msg = OK;

   mca = checkmca();
   if (mca)                      /* are we on a Micro Channel system? */
      msg = findmcacontroller(); /* yes - set baseport value */
   else
      baseport = DEFAULTBASEPORT;
   if (msg == OK)
      msg = initbuscontroller(); /* initialize E271-2201 and E271-2202 */
   if (msg == OK)
      msg = clearbuscontroller();
   if (msg != OK)
      quit(errormsg(msg));
}

int initbuscontroller(void)
{
   packettype ack,quiet = {'Q',2,0,0,0,0,0,0};
   byte b;

   b = (byte)inp(baseport) & (byte)0x7f;  /* command byte is guaranteed A-Z */
   if ((b < (byte)'A') || (b > (byte)'Z'))
      return(NOCONTROLLER);
   sendpacket(quiet);               /* enable controller */
   if (!getpacket(ack,'A'))         /* any ack? */
      return(NOCONTROLLER);
   return(OK);
}

int clearbuscontroller(void)
{
   int count=250;
   packettype garbage;

   do {
      if (getanypacketbus(garbage))
         count--;
      else
         return(OK);
   } while (count > 0);
   return(SHORTED);
}

void disablecontroller(void)
{
   if (mca)
      resetmcacontrollerpos();
}

boolean getpacket(packettype packet, byte p)
/* discard all packets until we see the packet requested by p */
{
   int i;

   for (i=0; i<10; i++) {
      if (!getanypacketbus(packet))
         break;
      if (*packet == p)
         return(TRUE);
   }
   return(FALSE);
}

boolean getanypacketbus(packettype packet)
{
   unsigned i;
   byte *p;

   currenttime = getclocktime();
   do {
      if (timeout(2))
         return(FALSE);
   } while (inp(baseport) & 0x80);        /* not ready */
   for (i=0, p=packet; i<8; i++)          /* read 8 consecutive I/O ports */
      *p++ = (byte)inp(baseport+i);
   currenttime = getclocktime();
   do {
      if (timeout(1))
         return(FALSE);
   } while (*packet == (byte)inp(baseport)); /* wait for byte 0 to change */
   return(TRUE);     /* so we don't read the same data twice on a fast PC */
}

boolean sendpacket(packettype packet)
{
   unsigned i;

   for (i=0; i<8; i++)              /* output to 8 consecutive I/O ports */
      outp(baseport+i,*packet++);
   return(TRUE);
}

/************************** Micro Channel Specific ***********************/

boolean checkmca(void)
/* check if running on MCA */
{
   boolean mca_found = FALSE;

   _asm {
      mov   ah,0c0h     ; get BIOS ID
      mov   bx,-1
      stc
      int   15h
      jc    no_mca
      cmp   bx,-1
      je    no_mca
      test  byte ptr es:[bx+5],2
      jz    no_mca
      mov   mca_found,1
no_mca:
   }
   return(mca_found);
}

int findmcacontroller(void)
{
   unsigned posbase,j;
   byte mcainfo[8],i;
   union REGS regs;

   regs.x.ax = 0xc400;
   int86(0x15,&regs,&regs);
   posbase = regs.x.dx;
   for (i=1; i<9; i++) {         /* check each slot for 2202 controller */
      regs.x.ax = 0xc401;
      regs.h.bl = i;
      int86(0x15,&regs,&regs);
      for (j=0; j<8; j++)        /* read ID and POS registers */
         mcainfo[j] = (byte)inp(posbase+j);
      regs.x.ax = 0xc402;
      regs.h.bl = i;
      int86(0x15,&regs,&regs);
      if (((mcainfo[0] + ((unsigned)mcainfo[1] << 8)) == IBM_ID) &&  /* check ID */
          ((mcainfo[6] + ((unsigned)mcainfo[7] << 8)) == ~IBM_ID)) {
         baseport = mcainfo[3] + ((unsigned)mcainfo[4] << 8);
      /* intrpt = mcainfo[5] & 0xf; */
         return(OK);
      }
   }
   return(NOCONTROLLER);
}

void resetmcacontrollerpos(void)
/* disable controller so it can be detected again through POS registers */
{
   static packettype quiet = {'Q',1,0,0,0,0,0,0};

   sendpacket(quiet);      /* no acknowledge on Quiet-all command */
}
