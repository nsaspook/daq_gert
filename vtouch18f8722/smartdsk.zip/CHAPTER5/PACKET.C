/*****************************************************************************

PACKET.C - Packet definitions and interface dependant routing functions.

Copyright (C) 1990
	Elo TouchSystems, Inc.
	105 Randolph Road
	Oak Ridge, TN  37830
	(615) 482-4100

Written on August 23, 1990 by Lawrence Adams.

Notes:

	Global packet types and default definitions are declared here and as 
	externals in PACKET.H.

	The procedures in this module take generic commands like 'initcontroller' 
	and 'getanysmartsetpacket' and route them to the interface specific procedures
	in SERIAL.C, PCBUS.C and MCA.C.

Revision History:

*****************************************************************************/

#include <stdio.h>
#include <process.h>
#include "console.h"
#include "packet.h"
#include "serial.h"
#include "pcbus.h"
#include "mca.h"

unsigned 
	interfacetype = _PCBUS_,				/* global interface type specifier */
	screentype = _ACCU_,						/* global screen type specifier */
   controllertype = _2201_;				/* global controller number */

				/* config variable parameters and their default values */
packettype
		/* loadable configuration defaults */
	report 	= {'B',0x00,0x02,0x00,0x00,0x00,0x00,0x00},
	calibs 	= {'C', 'S', '0',0x00,0x00,0x00,0x00,0x00},
	calibpx	= {'C', 'x',0x00,0x00,0xff,0x0f,0xff,0x0f},
	calibpy	= {'C', 'y',0x00,0x00,0xff,0x0f,0xff,0x0f},
	calibpz	= {'C', 'z',0x00,0x00,0xff,0x00,0xff,0x00},
	emulate	= {'E', '1', '4',0x00,0x00,0x00,0x00,0x00},
	filtr  	= {'F', '1',0x04,0x08,0x08,0x90,0x00,0x00},
	usrtimer = {'H', '0', '0',0x00,0x64,0x00,0x64,0x00},
	keychar	= {'K',0x00,0x00,0x00,0x00,0x00,0x00,0x00},
	lowpwr 	= {'L', '0',0x00,0x00,0x00,0x00,0x00,0x00},
	tmode  	= {'M',0x00,0x87,0x00,0x00,0x00,0x00,0x00},
	params 	= {'P', '0',0x05,0x04,0x00,0x00,0x00,0x00},
	quiet  	= {'Q',0x00,0x00,0x00,0x00,0x00,0x00,0x00},
	scales	= {'S', 'S',0x00,0x00,0x00,0x00,0x00,0x00},
	scalepx	= {'S', 'x',0x00,0x00,0xff,0x0f,0xff,0x0f},
	scalepy	= {'S', 'y',0x00,0x00,0xff,0x0f,0xff,0x0f},
	scalepz	= {'S', 'z',0x00,0x00,0xff,0x00,0xff,0x00},

	dfltserparams	= {'P', '0',0x05,0x04,0x00,0x00,0x00,0x00},
	dfltbusparams	= {'P', '1', '0',0x00,0x80,0x02,0x00,0x00},
	dfltmcaparams	= {'P', '2', '0',0x00,0x00,0x00,0x00,0x00},
	lastparams,

									/* various other packets */
	ack	 	= {'A',0x00,0x00,0x00,0x00,0x00,0x00,0x00},
	calibrx	= {'C', 'X',0x00,0x00,0x00,0x00,0x00,0x00},
	calibry	= {'C', 'Y',0x00,0x00,0x00,0x00,0x00,0x00},
	calibrz	= {'C', 'Z',0x00,0x00,0x00,0x00,0x00,0x00},
	diag	  	= {'D',0x00,0x00,0x00,0x00,0x00,0x00,0x00},
	id	  		= {'I', '0', '0', '0',0x00,0x00,0x00,0x00},
	jumpers	= {'J',0x00,0x00,0x00,0x00,0x00,0x00,0x00},
	nvm		= {'N', '0', '0', '0',0x00,0x00,0x00,0x00},
	owner  	= {'O', 'E', 'l', 'o', 'I', 'n', 'c', '.'},
	reset		= {'R', '1',0x00,0x00,0x00,0x00,0x00,0x00},  /* soft reset */
	scalerx	= {'S', 'X',0x00,0x00,0x00,0x00,0x00,0x00},
	scalery	= {'S', 'Y',0x00,0x00,0x00,0x00,0x00,0x00},
	scalerz	= {'S', 'Z',0x00,0x00,0x00,0x00,0x00,0x00},
	touch 	= {'T',0x00,0x00,0x00,0x00,0x00,0x00,0x00};

/***************** interface independant controller routines ****************/

int initcontroller(void)
/* used only when SMARTSET is first run to initialize the controller */
{
	switch(interfacetype) {
		case _SERIAL_:
			return(initserialcontroller());
		case _PCBUS_:
			return(initpcbuscontroller());
		default:
			return(initmcacontroller());
	}
}

int clearcontroller(void)
/* clear controller of any partial input or output packets and old data */
{
	switch(interfacetype) {
		case _SERIAL_:
			return(clearserialcontroller());
		case _PCBUS_:
			return(clearbuscontroller());
		default:
			return(clearbuscontroller());
	}
}

boolean getsmartsetpacket(packettype packet, byte p)
/* get a specific SMARTSET series binary packet */
{
	if (interfacetype == _SERIAL_)
		return(getsmartsetpacketserial(packet,p));
	else
		return(getsmartsetpacketbus(packet,p));
}

boolean getanysmartsetpacket(packettype packet)
/* get any old SMARTSET series binary packet */
{
	if (interfacetype == _SERIAL_)
		return(getanysmartsetpacketserial(packet));
	else
		return(getanysmartsetpacketbus(packet));
}

int getanyASCIIpacket(char *packet, int maxlength, boolean lfstop)
/* get any ASCII packet from a SMATSET series controller */
{
	if (interfacetype == _SERIAL_)
		return(getanyASCIIpacketserial(packet, maxlength, lfstop));
	else
		return(getanyASCIIpacketbus(packet, maxlength, lfstop));
}

boolean getanyotherbinarypacket(packettype packet)
/* get any SMARTSET series binary emulation packet (140, 141, 280, 4002, 4025...) */
{
	if (interfacetype == _SERIAL_)
		return(getanyotherbinarypacketserial(packet));
	else
		return(getanyotherbinarypacketbus(packet));
}

boolean sendsmartsetpacket(packettype packet)
/* send a SMARTSET series binary packet to controller */
{
	if (interfacetype == _SERIAL_)
		return(sendsmartsetpacketserial(packet));
	else
		return(sendsmartsetpacketbus(packet));
}

void closesmartsetcontroller(void)
/* shut down a SMARTSET series controller */
{
	static packettype reset0 = {'R',0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	if (interfacetype == _MCA_)
		sendsmartsetpacketbus(reset0);		/* no acknowledge on R0 command */
}

char * errormsg(int errnum)
/* return a marginally human readable error message */
{
	switch (errnum) {
		case NOCONTROLLER:
			return("Controller not detected.");
		case SHORTED:
			return("Touchscreen fault - controller is transmitting continuously.");	
		case NOMCA:
			return("System does not have a Micro Channel(R) bus.");
		case CANTSEND:
			return("Cannot output to controller.");
		case NORESPONSE:
			return("Controller not responding.");	
		case WRONGRESPONSE:
			return("Controller not responding correctly.");
		case NOPCBUS:
			return("System does not have a PC-Bus.");
		case NOOPEN:
			return("Cannot open file.");
		case NOREAD:
			return("Error reading configuration file.");
		case NOUPLOAD:
			return("Error loading: Current information not correct.");
		case NOMCACONTROLLER:
			return("Cannot auto-detect controller, may be in use.");
		case NOACK:
			return("Controller not acknowledging.");
		case NOFILE:
			return("Cannot find SmartSet configuration file on disk.");
		case WRONGVERSION:
			return("SmartSet information is from different ROM version.");
		case NOCREATE:
			return("Cannot create SmartSet configuration file.");
		case NOSETUP:
			return("Setup data not found in configuration file.");
		case NOCAL2:
			return("Second calibration data not found in configuration file.");
		case NOCOMM:
			return("Cannot do unless communicating with controller.");
		case MCACOMM:
			return("Cannot alter parameters on Micro Channel card.");
		case NOCOMPARE:
			return("Setup data in NVRAM did not compare to SmartSet setup.");
		case DIVZER:
			return("Divide by zero.");
		case BADINP:
			return("Bad input packet.");
		case BADCRC:
			return("Bad input checksum.");
		case OVRRUN:
			return("Input packet overrun.");
		case ILLCMD:
			return("Illegal command.");
		case CALIBCANCL:
			return("Calibration command cancelled.");
		case BADSERSETUP:
			return("Bad serial communication setup combination.");
		case EEPROM:
			return("NVRAM not valid - initializing.");
		case NOSET:
			return("No set available for this command.");
		case UNSUPP:
			return("Unsupported in this firmware version.");
		case ILLSUB:
			return("Illegal subcommand.");
		case OUTOFRANGE:
			return("Operand out of range.");
		case INVTYPE:
			return("Invalid type.");
		case FATALERR:
			return("Fatal error condition exists.");
		case NOQUERY:
			return("No query available for this command.");
		case INVINT:
			return("Invalid interrupt number.");
		case NVRAMFAIL:
			return("NVRAM failure.");
		case BADADDRESS:
			return("Invalid address number.");
	}
	return("");
}
