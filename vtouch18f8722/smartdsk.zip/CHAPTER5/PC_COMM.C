/*************** PC-dependent serial communications code *****************/

/* offsets from base of UART Registers for IBM PC */
#define  UART_THR 0x00  /* transmit holding reg. */
#define  UART_RBR 0x00  /* receiver buffer reg. */
#define  UART_LBR 0x00  /* baud rate divisor reg. (low) */
#define  UART_HBR 0x01  /* baud rate divisor reg. (high) */
#define  UART_IER 0x01  /* interrupt enable reg. */
#define  UART_IIR 0x02  /* interrupt identification reg. */
#define  UART_LCR 0x03  /* line control reg. */
#define  UART_MCR 0x04  /* modem control reg. */
#define  UART_LSR 0x05  /* line status reg. */
#define  UART_MSR 0x06  /* modem status reg. */

unsigned bios_port_addr[2] = {0x3f8,0x2f8};
byte     baud_rate_divisor[8][2] = {1, 0x80,    /* 300 */
                                    0, 0xc0,    /* 600 */
                                    0, 0x60,    /* 1200 */
                                    0, 0x30,    /* 2400 */
                                    0, 0x18,    /* 4800 */
                                    0, 0x0c,    /* 9600 */
                                    0, 0x06,    /* 19.2k */
                                    0, 0x03};   /* 38.4k */

unsigned uartbase;

void comport_enable(void)
/* set RTS on 8250 */
{
   outp(UART_MCR + uartbase, 0x03);
}

void comport_disable(void)
/* clear RTS on 8250 */
{
   outp(UART_MCR + uartbase, 0x01);
}

boolean comport_init(byte comport, byte baudrate, byte parity, byte data, byte stop)
{
   byte b;

   _disable();
   /* set baud rate */
   uartbase = bios_port_addr[--comport];
   outp(UART_LCR + uartbase, 0x80);
   outp(UART_HBR + uartbase, baud_rate_divisor[baudrate][0]);
   outp(UART_LBR + uartbase, baud_rate_divisor[baudrate][1]);
   /* set data, stop length, parity */
   if (data == 1)
      b = 0x02;                  /* 7 bits */
   else
      b = 0x03;                  /* 8 bits */
   if (stop == 1)
      b |= 0x04;                 /* 2 bits */
   switch(parity) {
      case 0:break;              /* none */
      case 1:b |= 0x08; break;   /* odd */
      case 2:b |= 0x18; break;   /* even */
      case 3:b |= 0x28; break;   /* mark */
      case 4:b |= 0x38;          /* space */
   }
   outp(UART_LCR + uartbase, b);
   /* make sure interrupts are disabled */
   outp(UART_IER + uartbase, 0);
   /* read the Line Status Register to reset any errors it indicates */
   b = (byte)inp(UART_LSR + uartbase);
   /* read the Receiver Buffer Register in case it contains a character */
   b = (byte)inp(UART_RBR + uartbase);
   comport_disable();
   _enable();
   return(inp(UART_MSR + uartbase) & 0x20);  /* DSR if controller there */
}

boolean comport_xmit_ok(void)
/* return status of CTS (controlled by 2000 controller) */
{
   return(inp(UART_MSR + uartbase) & 0x10);
}

boolean comport_receive(byte *b)
/* wait for an incoming character */
{
   currenttime = getclocktime();
   do 
      if (timeout(2))
         return(FALSE);
   while (!(inp(UART_LSR + uartbase) & 0x01));
   _disable();       /* disable interrupts */
   *b = (byte)inp(UART_RBR + uartbase);
   _enable();        /* enable interrupts */
   return(TRUE);
}

boolean comport_send(byte b)
/* wait for Transmit Hold Register Empty (THRE) */
{
   currenttime = getclocktime();
   do 
      if (timeout(2))
         return(FALSE);
   while (!(inp(UART_LSR + uartbase) & 0x20));
   _disable();       /* Disable interrupts */
   outp(UART_THR + uartbase, b);
   _enable();        /* Enable interrupts */
   return(TRUE);
}

void comport_close(void)
{
}
