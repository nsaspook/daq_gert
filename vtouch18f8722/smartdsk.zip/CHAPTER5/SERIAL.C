/*****************************************************************************

SERIAL.C - Serial I/O routines.

Copyright (C) 1990
	Elo TouchSystems, Inc.
	105 Randolph Road
	Oak Ridge, TN  37830
	(615) 482-4100

Written on February 5, 1990 by Lawrence Adams.

Notes:

	The routines in this module handle the communications between host and 
	controller that are specific to the E271-2200 serial, "smartset", 
	controller.

Revision History:

*****************************************************************************/

#include "console.h"
#include "highlvl.h"
#include "packet.h"
#include "serial.h"
#include "comm.h"

static int initserial(void);

byte 
	comport, 									/* global serial parameters */
	baudrate, 
	key, 											/* key character, 0 = disabled */
	echo, 										/* TRUE = full duplex */
	data, 
	parity, 
	stop; 

int 
	handshaking;								/* HARDWARE, INVERTED, SOFTWARE, NONE */

long 
	currenttime;								/* used for time out functions */

/******************** low-level serial controller routines ******************/

int initserialcontroller(void)
/* clear serial controller of old or partial data and any partial packets
	that may have been sent to it.  then test for communication with 
	controller. performed only during initialization when SMATSET is first 
	run */
{
	packettype ack = {'a',0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	int err;

	if ((err = initserial()) != OK)		/* init serial port to N,8,1 */
		return(err);
	if ((err = clearserialcontroller()) != OK) /* clear any old data */
		return(err);

	sendsmartsetpacketserial(ack);  		/* send an acknowledge packet */
	if (!getsmartsetpacketserial(ack,'A')) {/* any ack back? */
		quiet[0] = 'Q';						/* try resetting a possible 'Quiet All' */
		quiet[1] = 0x00;						/* init quiet packet (quiet none) */
		sendsmartsetpacketserial(quiet);	/* send quiet packet */			
		if (!getanysmartsetpacketserial(ack))/* still no ack? */		
			return(NORESPONSE);				/* not communicating */
		if (*ack != 'A')						/* got a packet but not an ack? */
			return(WRONGRESPONSE);			/* not communicating correctly */
		beep(500);								/* audio warning */
		outtextxy(5, 22, "Note: The state of the QUIET status was changed during initialization.", hlttext);
		pressanykey(24);						/* get user to hit key */
		outtextxy(5, 22, "                                                                      ", normtext);
	}

	return(OK);									/* communication established */
}

static int initserial(void)
/* init comport to standard parameters */
{
	if (!comport_init(comport, baudrate, 0, 0, 0))	/* NONE, 8, 1 */
		return(NOCONTROLLER);				/* cannot init controller */
	echo = FALSE;								/* no echo (full duplex) */
	handshaking = HARDWARE;					/* normal hardware handshaking */
	return(OK);									/* init performed ok */
}

int clearserialcontroller(void)
/* clear controller of any partially send or recieved packets or old data */
{
	int count=200, i;
	static packettype ack = {'a',0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	if (!comport_send(0x11))				/* ^Q */
		return(CANTSEND);						/* communication error */
	for (i=0; i<10; i++)						/* 10 chars to fill any partial packet */
		comport_send(0x00);
	if (!sendsmartsetpacket(ack))			/* send an acknowledge packet */
		return(CANTSEND);						/* communication error */
	do {											/* test if screen is shorted */
		if (getanysmartsetpacketserial(ack))	/* look for any kind of packet */
			count--;								/* got one?  try again... */
		else {
			comport_disable();
			return(OK);							/* none?  not shorted then */
		}
	} while (count > 0);
	return(SHORTED);							/* packets continously transmitted */
}

void waitforxmitok(void)
/* wait for signal from controller that it's ok to transmit. This is
	used rarely where there is no ack for a command (i.e. a hard reset). */
{
	switch(handshaking) {
		case HARDWARE:
		case INVERTED:		  
			waitabit(5);	 					/* allow reset time to de-assert CTS */
			do {} while (!comport_xmit_ok()); /* wait for hardware handshake to clear */
			break;
		case SOFTWARE:
		case NONE:		
			waitabit(819);						/* 45 sec. (maximum time for longest command to process */
			break;
	}
}

/************************* packet send/receive routines *********************/

boolean getsmartsetpacketserial(packettype packet, byte p)
/* receive and throw away packets until we get one of the type were looking
	for. used primarily to throw away unwanted timer or touch packets when
	we're looking for an acknowledge packet. */
{
	for (;;) {									
		if (!getanysmartsetpacketserial(packet)) 
			return(FALSE);						/* no packets available */
		if (p == *packet)
			return(TRUE);						/* found the type we were looking for */
	}
}

boolean getanysmartsetpacketserial(packettype packet)
/* get and return any valid serial packet. */
{
	byte sum=0, c;
	int bidx=0, lastbyte=0, count=500;

	comport_enable();							/* enable controller transmission */
	for (;;) {
		if (!comport_receive(&c)) {		/* if there is no data to receive... */
			comport_disable();				/* disable controller transmission */
			return(FALSE);						/* and return "no data" */
		}
		if (data)								/* 7 bit data? */
			c &= 0x7f; 							/* strip off high bit */
     	if (bidx == 0)							/* expecting new packet? */
			if (c == 'U') {					/* do we have one? */
				lastbyte = 9;					/* normal packet 10 (0..9) bytes long */
				sum = 0xaa + 'U';				/* yes - initialize checksum */
				bidx++;
			}
			else if (c == 0x16) {			/* (^V) extended packet? */
				lastbyte = 10;					/* extended packet 11 (0..10) bytes long */
				sum = 0xaa + 0x16;			/*	initialize checksum */
				bidx++;
			}
			else {
				if (!(--count))
					return(FALSE);				/* incorrect data: no packet init char */
													/*		or several packets with invalid chksums */
				continue;						/* no - discard character */
			}
		else if ((lastbyte == 10) && (bidx == 9)) { /* key character? */
			sum += c;							/* add to checksum but don't store! */
			bidx++;
		}
     	else if (bidx == lastbyte) { 		/* end of packet? */
			if (data)							/* 7 bit data? */
				sum &= 0x7f;					/* strip off high bit of chksum */
		 	if (sum == c) {					/* does checksum match? */
				comport_disable();			/* yes - done */
				return(TRUE);
			}
			bidx = 0;							/* no - start over */
		}
		else
			sum += (packet[bidx++ - 1] = c);	/* store packet data */
	}
}

int getanyASCIIpacketserial(char *s, int maxlength, boolean lfstop)
/* returns all character data from serial port until:
	s > maxlength chars, comport timeout or LF(if lfstop is true) 
	data formats:
	60		 : [x][x][x][x][ ][y][y][y][y]([ ][U|T])[CR][LF]
	140	 : [CR][LF][x][x][x][x][ ][y][y][y][y]([ ][U|T])
	280	 : [x][x][,][y][y]([U\T)[CR][LF]
   4002 	 : [CR][LF][x][x][x][x][ ][y][y][y][y]([ ][z][z][z][z]([U|T]))
	SMARSET: ([-])([x])[x][x][x][x][ ]([-])([y])[y][y][y][y][ ]...
		      ([-])([z])[z][z][z][z]([ ][U|T])[CR][LF]

	for 140 data this routine throws away the cr\lf and returns false, then
	continues as if data is aligned like 280 data.  The end of the last 140
	packet in a stream is caught by a comport timeout.  This would of course 
	have to reworked for other applications since a comport timeout is NOT
	guaranteed at the end of a touch stream (a waiting ACK from controller for 
	example could be tacked onto the end of the touch data stream).
*/
{
	byte c;
	int idx = 0;
	
	comport_enable();							/* enable controller transmission */
	for (;;) {
		if (!comport_receive(&c) || (idx == maxlength)) {
			comport_disable();				/* no more data */
			s[idx] = '\0';						/* terminate data string */
			return(idx);						/* return length of string */
		}
		if (!((c=='\r')||(c=='\n')))		/* store data if not a CR or LF */
			s[idx++] = c;
		if ((lfstop) && (c == '\n')) {	/* IF we are looking for a CR/LF and found one... */
			comport_disable();				/* stop data transmission */
			s[idx] = '\0';						/* terminate data string */
			return(idx);						/* return string length */
		}
	}	
}

boolean getanyotherbinarypacketserial(packettype packet)
/* gets binary data in 140, 280, 4001, 4002 (400) mode emulation 
	data is as follows:
	140:	byte 0: 11XX XXXX  X - most sig. bits
			byte 1: 10XX XXXX  X - least sig. bits
			byte 2: 01YY YYYY  Y - most sig. bits
			byte 3: 00YY YYYY  Y - least sig. bits
  
	280:	byte 0: 0000 0001  start of packet for touch data
					  1000 0001  start of packet for untouch data
			byte 1: XXXX XXXX  X - data
			byte 2: YYYY YYYY  Y - data

	400:  byte 0: 11XX XXXX  X - most sig. bits
			byte 1: 10XX XXXX  X - least sig. bits
			byte 2: 01YY YYYY  Y - most sig. bits
			byte 3: 00YY YYYY  Y - least sig. bits
			byte 4: 0000 0000  Always zero
			byte 5: 0000 ZZZZ  Z Range: 1 - 15
*/
						
{
	int nextchar, firstchar;
	byte c;
	boolean done = FALSE;

	firstchar = nextchar = ((emulate[2] & 0x07) == 0x06) ? 5 : 3;	/* emulate mode 6 = 4002 binary */
	comport_enable();							/* enable controller transmission */
	do {
		if (!comport_receive(&c)) {		/* no data */
			comport_disable();				/* disable controller transmission */
			return(FALSE);						/* return "no data" */
		}
		if ((emulate[2] & 0x07) == 2) { 	/* 280 controller */
			if (nextchar == 3) {				/* if expecting new packet... */
				if ((c == 1) || (c == 0x81)) { /* if it IS a new packet... */
					packet[2] = c;				/* store data */
					nextchar = 1;				/* reset byte counter */
				}
				continue;
			}
		}
		else if ((c & 0xc0) == 0xc0)		/* 1st byte in packet? */
			nextchar = firstchar;			/* reset byte counter */
		packet[nextchar] = c;				/* store data */
		if (nextchar-- == 0)					/* last byte of packet? */
			done = TRUE;
	} while (!done);
	comport_disable();						/* disable controller transmission */
	return(TRUE);								/* return "valid data" */
}

boolean sendsmartsetpacketserial(packettype packet)
/* send a SMARSTET format packet to controller */
{
	int i, lastbyte;
	char c;
	byte sum=0;

	currenttime = getclocktime();			/* save current time */
	do 											
		if (timeout(currenttime, 2))		/* comport not ready to accept data */
			return(FALSE);						/* return "no send" */
	while (!comport_xmit_ok());			/* while comport not ready */
	if (key) 									/* extended packet */
		lastbyte = 10;
	else				  							/* normal packet */
		lastbyte = 9;
	comport_enable();							/* enable controller transmission */
	for (i=-1; i<lastbyte; i++) {			/* send packet... */ 
		if (i < 0) {							/* send packet header */
			if (key) 							/* if extended packet... */
				c = 0x16;						/* packet header = ctrl V */
			else 									/* normal packet... */
				c = 'U';							/* packet header = 'U' */
			sum = (byte)(0xAA + c); 		/* initialize checksum */
		}
		else if ((key) && (i == lastbyte - 2)) /* if in position to send key char... */
			sum += (c = key);
		else if (i == lastbyte - 1)		/* if in position ready to send chksum... */
			c = sum;
		else
			sum += (c = packet[i]);			/* send packet character */
		if (!comport_send(c)) {				/* if send failes... */
			comport_disable();				/* disable controller transmission */
			return(FALSE);						/* return "not sent" */
		}
		if (echo)								/* half duplex? */
			comport_receive(&c);				/* get and discard echoed character */
	}
	comport_disable();						/* disable controller transmission */
	return(TRUE);								/* return "packet sent" */
}


