#include <dos.h>

#define PCMONOSCREENBASE  0xb0000000L
#define PCCOLORSCREENBASE 0xb8000000L

unsigned videomode;        /* 7=mono, 3=color */
byte far *screenbase;      /* video RAM address */
long currenttime;          /* for use with timeout function */

void setvidmode(unsigned vidmode)
{
   union REGS regs;

   regs.x.ax = vidmode;
   int86(0x10,&regs,&regs);
}

unsigned getvidmode(void)
{
   union REGS regs;

   regs.h.ah = 0x0f;
   int86(0x10,&regs,&regs);
   return((unsigned)regs.h.al);
}

void cursoron(void)
{
   union REGS regs;

   regs.h.ah = 0x01;
   regs.x.cx = (videomode == 7) ? 0x0a0b : 0x0607;
   int86(0x10,&regs,&regs);
}

void cursoroff(void)
{
   union REGS regs;

   regs.h.ah = 0x01;
   regs.x.cx = 0x2000;
   /* Be sure not in transition to/from vertical retrace. */
   /* This code seems to guarantee cursor goes off, */
   /* where on many adapters it is intermittent. */
   if (videomode == 3) {
      while ((inp(0x3da) & 8) == 0) ;
      while ((inp(0x3da) & 8) != 0) ;
   }
   int86(0x10,&regs,&regs);
}

void cursorxy(unsigned xpos, unsigned ypos)
{
   union REGS regs;

   regs.h.ah = 0x02;
   regs.h.bh = 0;
   regs.x.dx = ((ypos - 1) << 8) + (xpos - 1);
   int86(0x10,&regs,&regs);
}

void clearscreen(void)
/* clears text mode screen */
{
   union REGS regs;

   regs.x.ax = 0x0600;
   regs.h.bh = 7;
   regs.x.cx = 0;
   regs.x.dx = (24 << 8) + 79;
   int86(0x10,&regs,&regs);
   cursorxy(1,1);
}

void openscreen(void)
{
   if ((videomode = getvidmode()) == 7) {
      screenbase = (byte far*)PCMONOSCREENBASE;
   }
   else {
      if (videomode != 3)
         setvidmode(videomode = 3);
      screenbase = (byte far*)PCCOLORSCREENBASE;
   }
}

void closescreen(void)
{
   setvidmode(videomode);
}

long getclocktime(void)
{
   long t;

   _disable();
   t = *(long volatile far *)0x40006CL;
   _enable();
   return(t);
}

boolean timeout(int len)
{
   return(((getclocktime() - currenttime) > len) ||
          ((getclocktime() - currenttime) < 0));
}
