/*************************************************************************

EXAMPLE1.C
   Polls Elo SmartSet touchscreen controllers.
   Displays controller ID, jumper settings, and raw touch coordinates.

**************************************************************************/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "packet.c"              /* SmartSet interface-independent code */
#include "pc_misc.c"             /* miscellaneous PC-dependent code */

void displayjumpers(void);

/*************************************************************************/

int _cdecl main(void)
{
   int x,y,z,flags;

   initcontroller();
   checkdiags();
   displayjumpers();
   printf("\nTouch screen for polled [X Y Z Status] output.\n");
   printf("Press any key to abort...\n");
   do {
      if (gettouch(&x,&y,&z,&flags))
         printf("%6d%6d%6d%6X\n",x,y,z,flags);
   } while (!kbhit());
   while (kbhit())            /* flush keystroke */
      getch();
   disablecontroller();
   return(0);
}

void displayjumpers(void)
{
   int i;
   packettype id,owner,jumpers;

   printf("ID:\n");
   id[0] = 'i'; querycommand(id);
   owner[0] = 'o'; querycommand(owner);
   printf("  Controller revision level: ");
   for (i=1; i<8; i++)
      printf("%c",owner[i]);
   printf(" %d.%d\n",id[5],id[4]);
   printf("  Z axis: ");
   if (id[3] & 0x80)
      printf("Available\n");
   else
      printf("Not available\n");

   printf("Jumper settings:\n");
   jumpers[0] = 'j'; querycommand(jumpers);
   printf("  Touchscreen type: "); 
   switch(jumpers[1]) {
      case '0': printf("AccuTouch\n"); break;
      case '1': printf("DuraTouch\n"); break;
      case '2': printf("IntelliTouch\n");
   }
   printf("  Interface: ");
   switch(jumpers[2]) {
      case '0': printf("Serial\n"); break;
      case '1': printf("PC-Bus\n"); break;
      case '2': printf("Micro Channel\n");
   }
   printf("  Boot from: ");
   if (jumpers[3] == '0') printf("Jumpers\n");
   else printf("NVRAM\n");
   printf("  Mode: ");
   if (jumpers[4] == '0') printf("Single-Point\n");
   else printf("Stream\n");
   if (jumpers[2] == '0') {      /* serial controller */
      printf("  Hardware handshaking: ");
      if (jumpers[6] == '1') printf("Enabled\n");
      else printf("Disabled\n");
      printf("  Output format: ");
      if (jumpers[7] == '0') printf("ASCII\n");
      else printf("Binary\n");
   }  
   else {
      printf("  Interrupt: %d\n", jumpers[5]);
      printf("  Base address: %X\n", jumpers[6]+(jumpers[7] << 8));
   }
}

#include "bus.c"              /* for E271-2201 and E271-2202 */
/* #include "serial.c" */     /* for E271-2200 and E271-2210 */
