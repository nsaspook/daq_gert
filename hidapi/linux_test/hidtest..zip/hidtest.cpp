/* ****************************************************

 Windows HID simplification

 Alan Ott
 Signal 11 Software

 8/22/2009

 Copyright 2009
 
 This contents of this file may be used by anyone
 for any reason without any conditions and may be
 used as a starting point for your own applications
 which use HIDAPI.

******************************************************* 

  MCP2210 HID programming example using C with the HIDAPI 
  library.

   https://github.com/signal11/hidapi
                                                                                                                                                               
  Download and install the hidapi library and the 
  prerequisites listed in the HIDAPI readme file.
   
  Goto the hidapi-master/hidtest directory and rename the 
  origional hidtest.cpp file to hidtset_orig.cpp.
 
  Copy this hidtest.cpp file into the directory in its place.
  To compile the hidtest.cpp file from the terminal:
  use: "make" in the hidtest directory. The make file 
  was created during the HIDAPI installation process.

  Run the compiled file, "hidtest-libusb" in a terminal with 
  "sudo ./hidtest-libusb" or "./hidtest-libusb" if the 
  99-hid.rule" has been copied to:
    /etc/udev/rules.d/.
 
  The program will output "Hello World" and "Voltage = x.xx",
  to the 16x2 LCD diplay. The voltage is read from a 
  potentiometer connected to the MCP3008's channel 0.

  Command response data from the MCP2210 is sent to
  the terminal. 

  The commands that this program uses configure the MCP2210's 
  VM ram only. The NVM is left unchanged.

  -------------- connections to the MCP2210 -----------------

         buf[4] bit 0 = CS 0    MPC3008 CS pin 
         buf[4] bit 1 = GPIO 1  display pin D4
         buf[4] bit 2 = GPIO 2  display pin D5
         buf[4] bit 3 = GPIO 3  display pin D6
         buf[4] bit 4 = GPIO 4  display pin D7
         buf[4] bit 5 = GPIO 5  display pin E
         buf[4] bit 6 = GPIO 6  diaplay pin RS
         buf[4] bit 7 = GPIO 7  diaplay pin RW 
         buf[5] bit 0 = GPIO 8  LED  

  *******************************************************/

#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include <hidapi.h>

// Headers needed for sleeping.
#ifdef _WIN32
	#include <windows.h>
#else
	#include <unistd.h>
#endif

unsigned char buf[64];      // command buffer writen to MCP2210
unsigned char rbuf[64];     // response buffer read from MCP2210
char snd = 0;               // data to send to LCD display
int res;                    // # of bytes sent from hid_read(), hid_write() functions

hid_device *handle;         // handle of device returned by hid_open()

#define MAX_STR 255
wchar_t wstr[MAX_STR];      // buffer for id settings strings from MPC2210
struct hid_device_info *devs, *cur_dev;
	
// function prototypes: for LCD display

void initLCD();             // initializes 16x2 LCD display
void toggle_E();            // transfers data on GPIO pins int LCD display
void sendchar(char data);   // sends data for the Display to the GPIO pins
void command(char cmd);     // sets RS, RW values for an LCD command
void data(char ch);         // sets RS, RW values for LCD data to display

int main(int argc, char* argv[])
{	
// ------------------ List HID devices attached ------------------
#ifdef WIN32
	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);
#endif
	
	if(hid_init())
		return -1;

	devs = hid_enumerate(0x0, 0x0);
	cur_dev = devs;	
	while (cur_dev) {
	 	printf("Device Found\n  type: %04hx %04hx\n  path: %s\n  serial_number: %ls", cur_dev->vendor_id, cur_dev->product_id, cur_dev->path, cur_dev->serial_number);
	 	printf("\n\n");
	 	printf("  Manufacturer: %ls\n", cur_dev->manufacturer_string);
	 	printf("  Product:      %ls\n", cur_dev->product_string);
	  	printf("  Release:      %hx\n", cur_dev->release_number);
	  	printf("  Interface:    %d\n",  cur_dev->interface_number);
	  	printf("\n");
	  	cur_dev = cur_dev->next;
	  	}    
	hid_free_enumeration(devs);

	// Set up the command buffer -- memset() writes 256 0x00's to buf
       
	memset(buf,0x00,sizeof(buf)); // buf initialized to all zeros
	buf[0] = 0x01;
	buf[1] = 0x81;
	
//------------------ Open MCP2210 and display info ---------------

        printf("Open Device: 04d8:00de\n");
	// Open the device using the VID(vendor ID, PID(product ID),
	// and optionally the Serial number.
	handle = hid_open(0x4d8, 0xde, NULL);  // open the MCP2210 device
	if (!handle) {
		printf("unable to open the MCP2210\n");
 		return 1;	
                }
	// Read the Manufacturer String
	wstr[0] = 0x0000;
	res = hid_get_manufacturer_string(handle, wstr, MAX_STR);
	if (res < 0)
		printf("Unable to read manufacturer string\n");
	printf("Manufacturer String: %ls\n", wstr);

	// Read the Product String
	wstr[0] = 0x0000;
	res = hid_get_product_string(handle, wstr, MAX_STR);
	if (res < 0)
		printf("Unable to read product string\n");
	printf("Product String: %ls\n", wstr);

	// Read the Serial Number String
	wstr[0] = 0x0000;
	res = hid_get_serial_number_string(handle, wstr, MAX_STR);
	if (res < 0)
		printf("Unable to read serial number string\n");
	printf("Serial Number String: (%d) %ls", wstr[0], wstr);
	printf("\n");

	// Read Indexed String 1
	wstr[0] = 0x0000;
	res = hid_get_indexed_string(handle, 1, wstr, MAX_STR);
	if (res < 0)
		printf("Unable to read indexed string 1\n");
	printf("Indexed String 1: %ls\n\n", wstr);
 
//-------------------------- MCP2210 operations ------------------

       //-------------- Set GPIO pin function (0x21) -------------
        
        memset(buf,0,17); // buf initialized to zeros

        buf[0] = 0x21;    // command 21 - set GPIO pin's functions
	buf[4] = 0x01;    // GPIO 0 set to 0x01 = SPI CS, rest set to 0x00 = GPIO

	// function: 0x00 = gpio, 0x01 = CS, 0x02 = dedicated function
        // with buf all zeros, all 9 GPIO pins are set to GPIO's 

	res = hid_write(handle, buf, 17); // write pin funtion settings into MCP2210  
	if (res < 0) {
		printf("Unable to write()\n");
		printf("Error: error setting pin function %ls\n", hid_error(handle));
                }
        res = hid_read(handle, rbuf, 2); // read the 0x21 respose 
        
        //------------- Get GPIO pin function (0x20) -------------

        buf[0] = 0x20;  // command to get GPIO function

        res = hid_write(handle, buf, 2); // write pin funtion settings into MCP2210  
	if (res < 0) {
		printf("Unable to write()\n");
		printf("Error: error getting pin function %ls\n", hid_error(handle));
                }
        res = hid_read(handle, rbuf, 14); // read the 0x20 respose 

	printf("GPIO pin function:\n   ");  // Print out the 0x20 returned buffer.
	for (int i = 0; i < res; i++)
		printf("%02hhx ", rbuf[i]);
	printf("\n");
	
       // ------------ Set GPIO pin direction (0x32)--------------

        buf[0] = 0x32;   // command 32 - set GPIO pin's directions
    
	// function:  0 = output, 1 = input

        buf[4] = 0x00;   // set GPIO 0-7 to outputs 
	buf[5] = 0x00;   // set GPIO 8 to output  
	res = hid_write(handle, buf, 17); // write setting into MCP2210
	if (res < 0) {
		printf("Unable to write()\n");
		printf("Error: setting pin direction %ls\n", hid_error(handle));
                }

        res = hid_read(handle, rbuf, 21);  // read the 0x32 response from MCP2210
        
       // ------------ Get GPIO pin direction (0x33) -------------
 
        buf[0] = 0x33;

        res = hid_write(handle, buf, 2); // write setting into MCP2210
	if (res < 0) {
		printf("Unable to write()\n");
		printf("Error: setting pin direction %ls\n", hid_error(handle));
                }

        res = hid_read(handle, rbuf, 6);  // read the 0x33 response from MCP2210

	printf("GPIO pin direction\n   "); // Print out the 0x33 returned buffer.
	for (int i = 0; i < res; i++)
		printf("%02hhx ", rbuf[i]);
	printf("\n");

       // ----------- Set SPI transfer settings 0x40) ------------

        memset(buf,0,sizeof(buf));  // initialize buf to zeros
        buf[0] = 0x40;   // SPI transfer settings command
	
        buf[4] = 0x40;   // set SPI transfer bit rate; 0x000f4240 = 1,000,000
        buf[5] = 0x42;   // 32 bits, lsb = buf[4], msb buf[7]
        buf[6] = 0x0f;   
        buf[7] = 0x00;   

        buf[8] = 0xff;   // set CS idle values to 1
        buf[9] = 0x01;
        
        buf[10] = 0x00;  // set CS active values to 0
        buf[11] = 0x00;

        buf[18] = 0x04;  // set no of bytes to tansfer = 4

        res = hid_write(handle, buf, 21); // write setting into MCP2210
        if (res < 0) {
		printf("Unable to write()\n");
		printf("Error: setting SPI transfer settings %ls\n", hid_error(handle));
                }

        res = hid_read(handle, rbuf, 21);  // read the 0x40 response from MCP2210

       // ---------- Get SPI transfer settings (0x41)-------------

        buf[0] = 0x41;  // 0x41 Get SPI transfer settings
   
        res = hid_write(handle, buf, 2); // write setting into MCP2210
        if (res < 0) {
	        printf("Unable to write()\n");
		printf("Error: setting pin direction %ls\n", hid_error(handle));
                }

        res = hid_read(handle, rbuf, 21);  // read the 0x41 response from MCP2210
        printf("SPI transfer settings\n   "); // Print out the 0x41 returned buffer.
        for (int i = 0; i < res; i++)
		printf("%02hhx ", rbuf[i]);
        printf("\n");

       //------------- set GPIO pin values (0x30) ----------------

        buf[0] = 0x30;  // command to write GPIO pin values (used in LCD functions)
       
//-------------------- 16x2 lcd operations -----------------------

	initLCD();      // intitialize the 16x2 display

        char msg[] = {"Hello World"};

        for(int i = 0; i < (sizeof(msg)-1);i++)
          	data(msg[i]); // send msg to the LCD display
        for(int i = 0;i < (41-sizeof(msg));i++)  // hack to position cursor on 2nd line 
          	data(' ');    // the display used doesn't respond to the "setDdram" command ??
         
//---------------- MCP3008 A/D converter operations --------------
          
        memset(buf,0,17);             // buf initialized to zeros
        memset(rbuf,0,sizeof(rbuf));  // rbuf initialized to all zeros  

        buf[0] = 0x42;                // transfer SPI data command
        buf[1] = 4;                   // no. of SPI bytes to transfer
        buf[4] = 0x80;                // MSB sent first - single ended. channel 0,  SGL/DIF = 1; channel D2,D1,D0 = 0;
        
        for(int i = 0; i < 2; i++) {  // done twice as A hack to get rbuf[3] = 0x10 "spi transfer finished" response 5
          	res = hid_write(handle, buf, 6);  // write buf[0] thru  buf[7] 
         	usleep(4000);                     // 4ms delay for conversion to finish and send result
          	res = hid_read(handle, rbuf, 6);  // read 0x42 response data sent from MCP3008 (includes A/D voltage reading)
          	} 
        
        printf("SPI transfer response\n   "); // Print out the 0x42 returned buffer.
        for (int i = 0; i < res; i++)
		printf("%02hhx ", rbuf[i]);
       
// -------------- Write MCP3008 A/D conversion to the LCD --------
   
        char LCDbuf[15];         // buffer for volts converted to a decimal string
        unsigned int volts = ((rbuf[4] << 8) | rbuf[5]);   // put A/D voltage read into variable volts            
                                 // 10 bit A/D result is in buf[4] - 2 bits, and buf[5] - 8 bits
        sprintf(LCDbuf,"volts = %d.%02d", volts/100, volts%100); // convert volts hex to decimal string
                                 // %02d - pads decimal places with 0's to 2 places .xx
        memset(buf,0,17);        // buf initialized to zeros        
        buf[0] = 0x30;           // set buf[0] to write GPIO data command

        for(int i = 0;i < 12; i++)
          if(LCDbuf[i] != 0)     // don't send a string termination 0
            data(LCDbuf[i]);     // send the converted voltage string in LCDbuf to the LCD display 
        
        printf("\n%s\n\n",LCDbuf); // also send the voltage string to the terminal  
  
// ------------------------ Blink the LED ------------------------

                          // GPIO 8's function was changed by 0x42-SPI transfer 
                          // data function, and needs to be reset to GPIO
        buf[0] = 0x21;    // command 0x21 - Set GPIO pin functions
	buf[4] = 0x01;    // GPIO 0 set to 0x01 = SPI CS, GPIO 2-7 set to 0 = GPIO
        buf[5] = 0x00;    // GPIO 8 set to 0 = GPIO function
	res = hid_write(handle, buf, 6);  // write pin funtion settings into MCP2210 
        res = hid_read(handle, rbuf, 2);  // read 0x21 respose  
         
        printf("Ctrl c to exit\n"); // ctrl c to exit blink loop and exit program
 
        buf[0] = 0x30;    // command 0x30 to set GPIO pin values
        
        while(1){         // blink LED loop
        	buf[5] ^= 1;  // toggle buf[5] bit 0 = GPIO 8 - LED
  		res = hid_write(handle, buf,6);  // write 6 bytes of buf to MCP2210  
        	res = hid_read(handle, rbuf,6);  // read the 0x30 response 
        	usleep(400000); // delay .4 sec. for blink duration
                }  // max frequency without a delay is about 506Hz - 1975 usec.
      
// -----------------------Close and exit--------------------------  

	hid_close(handle);
	
	hid_exit(); /* Free static HIDAPI objects. */
 
#ifdef WIN32
	system("pause");
#endif
	return 0;
}  // -------------------- end of main() -------------------------

/************************************************************************************************/

// --------------------- 16x2 LCD functions ----------------------

void initLCD()  // initialize 16x2 display to 4 bit interface
{       
  	snd &=  0x00;         // E, RS, RW LOW
        buf[0] = 0x30;
        buf[4] = (snd<<1);    // shift snd over 1 place to match GPIO connection to 16x2
        
  	res = hid_write(handle, buf, 6);  // write 6 bytes of buf to MCP2210  
        res = hid_read(handle, rbuf, 6);  // read the 0x30 response but don't do anything with it 
         
  	usleep(15000);        // delay 15ms 	
        snd |= 0x03;          // display data pins D4 & D5 HIGH        
        buf[4] = (snd<<1);    // shift snd over a place to match GPIO connection to 16x2
  	res = hid_write(handle, buf, 6);  // write buf[0] - buf[5] 
  	res = hid_read(handle, rbuf, 6);  // read the 0x30response but don't do anything with it 
        usleep(5000);         // delay 5ms 
  	toggle_E();           // toggle E HIGH then LOW
  	toggle_E();           // toggle E HIGH then LOW     	
  	toggle_E();           // toggle E HIGH then LOW
  	snd &= 0xfe;          // display data pin 4 LOW        
  	toggle_E();           // function set: D4 = 4 bit interface 
  	command(0x28);        // function set: 2 line display 	
        command(0x10);        // set cursor        
  	command(0x0C);        // display on      
  	command(0x06);        // entry mode set        
  	command(0x01);        // clear display       
}

void toggle_E()               // toggle_E() puts the data on the GPIO pins and toggles E 
{
  	snd |= 0x10;          // E bit HIGH in buf[4]
        buf[4] = (snd<<1);    // shift snd over 1 place to match the GPIO connection to 16x2
        res = hid_write(handle, buf, 6);  // write 6 bytes of buf to MCP2210 
        res = hid_read(handle, rbuf, 6);  // read the 0x30 response but don't do anything with it
  	snd  &=  0xef;        // E bit LOW in buf[4]
  	buf[4] = (snd<<1);    // shift snd over 1 place to match GPIO connection to 16x2
        res = hid_write(handle, buf, 6);  // write 6 bytes of buf to MCP2210
        res = hid_read(handle, rbuf, 6);  // read the 0x30 response but don't do anything with it  
}

void sendchar(char data)      // divide the data into 2 nibbles and send to display
{       
  	snd &= 0xf0;          // clear lower 4 buf[4] data bits
  	snd |= (data>>4);     // upper nibble of data, toggle_E into display
        toggle_E();  	
  	snd &= 0xf0;          // clear data bits
  	snd |= (data & 0x0F); // lower nibble, toggle_E into display
        toggle_E();
}

void command(char cmd)        // set RS and RW for a command to the display
{
  	snd &= 0xdf;          // RS, bit LOW in buf
  	snd &= 0xbf;          // RW, bit LOW in buf
      	sendchar(cmd);
}       

void data(char ch)            // set RS and RW for data to be displayed
{
  	snd |= 0x20;          // RS bit HIGH in buf
  	snd &= 0xbf;          // RW bit LOW in buf
       	sendchar(ch);
}
